/******************************************************************************
*
* spi_demo.c - SPI example main file
*
******************************************************************************/

/******************************************************************************
*
* Copyright 2014 Altera Corporation. All Rights Reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
* this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
*
* 3. The name of the author may not be used to endorse or promote products
* derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER "AS IS" AND ANY EXPRESS OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ARE DISCLAIMED. IN NO
* EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
* OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
* OF SUCH DAMAGE.
*
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include "alt_fpga_manager.h"
#include "alt_interrupt.h"
#include "alt_spi.h"

#define MIN(a, b) ((a) > (b) ? (b) : (a))

#define ARRAY_COUNT(array) (sizeof(array) / sizeof(array[0]))

#define SPI_MASTER_DEVICE     ALT_SPI_SPIM1               // Device to be used as master
#define SPI_SLAVE_DEVICE      ALT_SPI_SPIS1               // Device to be used as slave
#define SPI_SLAVE_SELECT      0x1                         // Slave select for SPIS1
#define SPI_SLAVE_IRQ         ALT_INT_INTERRUPT_SPI3_IRQ  // IRQ for SPIS1
#define SPI_SPEED             20000                       // SPI bus speed 
#define SPI_BUFFER_SIZE       128                          // Buffer size

// Context data structure used by the SPI slave interrupt
typedef struct SPI_SLAVE_CONTEXT_s
{
    ALT_SPI_DEV_t * device;             // slave device
    volatile ALT_STATUS_CODE status;    // current status
    uint16_t buffer[SPI_BUFFER_SIZE];   // data buffer
    size_t count;                       // data buffer fill level
}
SPI_SLAVE_CONTEXT_t;

uint16_t buffer_send[SPI_BUFFER_SIZE];
uint16_t buffer_recv[SPI_BUFFER_SIZE];

// Setup and configure FPGA
ALT_STATUS_CODE socfpga_fpga_setup(void);

// Cleanup FPGA control
ALT_STATUS_CODE socfpga_fpga_cleanup(void);

// Initialize interrupt subsystem and setup SPI interrupt
ALT_STATUS_CODE socfpga_int_setup(ALT_INT_INTERRUPT_t int_id, ALT_INT_TRIGGER_t trigger);

// Cleanup interrupt subsystem and the specific SPI interrupt
ALT_STATUS_CODE socfpga_int_cleanup(ALT_INT_INTERRUPT_t int_id);

// Initialize and setup SPI master device
ALT_STATUS_CODE socfpga_spi_setup_master(ALT_SPI_DEV_t * device);

// Initialize and setup SPI slave device
ALT_STATUS_CODE socfpga_spi_setup_slave(ALT_SPI_DEV_t * device);

// Cleanup SPI device
ALT_STATUS_CODE socfpga_spi_cleanup(ALT_SPI_DEV_t * device);

// Slave SPI Module ISR Callback
void spi_slave_isr_callback(uint32_t icciar, void * context);

// SPI Demo Master Slave Loopback Test
ALT_STATUS_CODE spi_demo_master_slave_loopback(ALT_SPI_DEV_t * device_master, ALT_SPI_DEV_t * device_slave, SPI_SLAVE_CONTEXT_t * slave_context);

// Initialize and setup SPI master and slave device, setup SPI slave interrupt
ALT_STATUS_CODE spi_demo_setup(ALT_SPI_DEV_t * device_master, ALT_SPI_DEV_t * device_slave, SPI_SLAVE_CONTEXT_t * slave_context);

// Cleanup SPI master and slave device, disable SPI slave interrupt
ALT_STATUS_CODE spi_demo_cleanup(ALT_SPI_DEV_t * device_master, ALT_SPI_DEV_t * device_slave);

/******************************************************************************/
/*!
 * Setup and configure FPGA.
 *
 * \return      result of the function
 */
ALT_STATUS_CODE socfpga_fpga_setup(void)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    
    printf("INFO: Setup FPGA System ...\n");

    if (status == ALT_E_SUCCESS)
    {
        status = alt_fpga_init();
    }

    // Verify power is on
    if (status == ALT_E_SUCCESS)
    {
        if (alt_fpga_state_get() == ALT_FPGA_STATE_POWER_OFF)
        {
            printf("ERROR: FPGA Monitor reports FPGA is powered off.\n");
            status = ALT_E_ERROR;
        }
    }

    // Take control of the FPGA CB
    if (status == ALT_E_SUCCESS)
    {
        status = alt_fpga_control_enable();
    }

    // Verify the MSELs are appropriate for the type of image we're using.
    if (status == ALT_E_SUCCESS)
    {
        ALT_FPGA_CFG_MODE_t mode = alt_fpga_cfg_mode_get();
        switch (mode)
        {
        case ALT_FPGA_CFG_MODE_PP32_FAST_AESOPT_DC:
        case ALT_FPGA_CFG_MODE_PP32_SLOW_AESOPT_DC:
        case ALT_FPGA_CFG_MODE_PP16_FAST_AESOPT_DC:
        case ALT_FPGA_CFG_MODE_PP16_SLOW_AESOPT_DC:
            printf("INFO: MSEL [%d] configured correctly for FPGA image.\n", (int)mode);
            break;
        default:
            printf("ERROR: Incompatible MSEL [%d] set. Cannot continue with FPGA programming.\n", (int)mode);
            status = ALT_E_ERROR;
            break;
        }
    }

    // Program the FPGA
    if (status == ALT_E_SUCCESS)
    {
        // This is the symbol name for the SOF file contents linked in.
        extern char _binary_soc_system_dc_rbf_start;
        extern char _binary_soc_system_dc_rbf_end;

        // Use the above symbols to extract the FPGA image information.
        const char *   fpga_image      = &_binary_soc_system_dc_rbf_start;
        const uint32_t fpga_image_size = &_binary_soc_system_dc_rbf_end - &_binary_soc_system_dc_rbf_start;

        // Trace the FPGA image information.
        printf("INFO: FPGA Image binary at %p.\n", fpga_image);
        printf("INFO: FPGA Image size is %u bytes.\n", (unsigned int)fpga_image_size);

        // Try the full configuration a few times.
        const uint32_t full_config_retry = 5;
        for (uint32_t i = 0; i < full_config_retry; ++i)
        {
            status = alt_fpga_configure(fpga_image, fpga_image_size);
            if (status == ALT_E_SUCCESS)
            {
                printf("INFO: alt_fpga_configure() successful on the %u of %u retry(s).\n",
                       (unsigned)(i + 1),
                       (unsigned)full_config_retry);
                break;
            }
        }
    }

    if (status == ALT_E_SUCCESS)
    {
        printf("INFO: Setup of FPGA successful.\n");
    }
    else
    {
        printf("ERROR: Setup of FPGA return non-SUCCESS %d.\n", (int)status);
    }

    printf("\n");
    
    return status;
}

/******************************************************************************/
/*!
 * Cleanup FPGA control.
 *
 * \return      result of the function
 */
ALT_STATUS_CODE socfpga_fpga_cleanup(void)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    
    printf("INFO: Cleanup of FPGA ...\n");

    if (alt_fpga_control_disable() != ALT_E_SUCCESS)
    {
        printf("WARN: alt_fpga_control_disable() returned non-SUCCESS.\n");
    }

    if (alt_fpga_uninit() != ALT_E_SUCCESS)
    {
        printf("WARN: alt_fpga_uninit() returned non-SUCCESS.\n");
    }

    return status;
}

/******************************************************************************/
/*!
 * Initialize interrupt subsystem and setup SPI interrupt.
 *
 * \param       int_id interrupt id
 * \param       trigger type of trigger to be used for the interrupt
 * \return      result of the function
 */
ALT_STATUS_CODE socfpga_int_setup(ALT_INT_INTERRUPT_t int_id, ALT_INT_TRIGGER_t trigger)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    printf("INFO: Setting up SPI interrupt.\n");

    // Initialize global interrupts
    if (status == ALT_E_SUCCESS)
    {
        status = alt_int_global_init();
    }

    // Initialize CPU interrupts
    if (status == ALT_E_SUCCESS)
    {
        status = alt_int_cpu_init();
    }

    // Set interrupt distributor target
    if (status == ALT_E_SUCCESS)
    {
        int target = 0x3;
        status = alt_int_dist_target_set(int_id, target);
    }

    // Set interrupt trigger type
    if (status == ALT_E_SUCCESS)
    {
        status = alt_int_dist_trigger_set(int_id, trigger);
    }

    // Enable interrupt at the distributor level
    if (status == ALT_E_SUCCESS)
    {
        status = alt_int_dist_enable(int_id);
    }

    // Enable CPU interrupts
    if (status == ALT_E_SUCCESS)
    {
        status = alt_int_cpu_enable();
    }

    // Enable global interrupts
    if (status == ALT_E_SUCCESS)
    {
        status = alt_int_global_enable();
    }

    printf("\n");
    
    return status;
}

/******************************************************************************/
/*!
 * Cleanup interrupt subsystem and the specific SPI interrupt.
 *
 * \param       int_id interrupt id
 * \return      result of the function
 */
ALT_STATUS_CODE socfpga_int_cleanup(ALT_INT_INTERRUPT_t int_id)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    printf("INFO: Cleaning up SPI interrupt.\n");

    // Disable global interrupts
    if(status == ALT_E_SUCCESS)
    {
        status = alt_int_global_disable();
    }

    // Disable CPU interrupts
    if(status == ALT_E_SUCCESS)
    {
        status = alt_int_cpu_disable();
    }

    // Disable SPI interrupt at the distributor level
    if(status == ALT_E_SUCCESS)
    {
        status = alt_int_dist_disable(int_id);
    }

    // Unregister SPI ISR
    if(status == ALT_E_SUCCESS)
    {
        status = alt_int_isr_unregister(int_id);
    }
    
    // Uninitialize CPU interrupts
    if(status == ALT_E_SUCCESS)
    {
        status = alt_int_cpu_uninit();
    }

    // Uninitialize Global interrupts
    if(status == ALT_E_SUCCESS)
    {
        status = alt_int_global_uninit();
    }
    
    return status;
}

/******************************************************************************/
/*!
 * Initialize and setup SPI master device
 *
 * \param       SPI master device
 * \return      result of the function
 */
ALT_STATUS_CODE socfpga_spi_setup_master(ALT_SPI_DEV_t * device)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
     
    printf("INFO: Init and setup SPI Master.\n");

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_init(SPI_MASTER_DEVICE, device);
    }

    if (status == ALT_E_SUCCESS)
    {
        ALT_SPI_CONFIG_t cfg =
        {
            .frame_size    = ALT_SPI_DFS_8BIT,
            .frame_format  = ALT_SPI_FRF_SPI,
            .clk_phase     = ALT_SPI_SCPH_TOGGLE_START,
            .clk_polarity  = ALT_SPI_SCPOL_INACTIVE_HIGH,
            .transfer_mode = ALT_SPI_TMOD_TXRX,
            .loopback_mode = false
        };

        status = alt_spi_config_set(device, &cfg);
    }

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_speed_set(device, SPI_SPEED);
    }

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_slave_select_enable(device, SPI_SLAVE_SELECT);
    }

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_enable(device);
    }

    return status;
}

/******************************************************************************/
/*!
 * Initialize and setup SPI slave device
 *
 * \param       SPI slave device
 * \return      result of the function
 */
ALT_STATUS_CODE socfpga_spi_setup_slave(ALT_SPI_DEV_t * device)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    
    printf("INFO: Init and setup SPI Slave.\n");

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_init(SPI_SLAVE_DEVICE, device);
    }

    if (status == ALT_E_SUCCESS)
    {
        ALT_SPI_CONFIG_t cfg =
        {
            .frame_size          = ALT_SPI_DFS_8BIT,
            .frame_format        = ALT_SPI_FRF_SPI,
            .clk_phase           = ALT_SPI_SCPH_TOGGLE_START,
            .clk_polarity        = ALT_SPI_SCPOL_INACTIVE_HIGH,
            .transfer_mode       = ALT_SPI_TMOD_TXRX,
            .slave_output_enable = true,
            .loopback_mode       = false
        };

        status = alt_spi_config_set(device, &cfg);
    }

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_enable(device);
    }

    return status;
}

/******************************************************************************/
/*!
 * Cleanup SPI device
 *
 * \param       SPI  device
 * \return      result of the function
 */
ALT_STATUS_CODE socfpga_spi_cleanup(ALT_SPI_DEV_t * device)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
     
    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_disable(device);
    }
    
    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_uninit(device);
    }

    return status;
}

/******************************************************************************/
/*!
 * Slave SPI Module ISR Callback
 *
 * \param       icciar
 * \param       context ISR context.
 * \return      none
 */
void spi_slave_isr_callback(uint32_t icciar, void * context)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    SPI_SLAVE_CONTEXT_t * ctxt = (SPI_SLAVE_CONTEXT_t *)context;

    uint32_t spi_int = 0;

    // Determine the interrupt type signaled.
    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_int_status_get(ctxt->device, &spi_int);
    }

    // Handle the interrupts
    if (status == ALT_E_SUCCESS)
    {
        printf("INFO [ISR]: spi_int = 0x%" PRIx32 ".\n", spi_int);

        if (spi_int & ALT_SPI_STATUS_TXEI) // TX FIFO Empty
        {
            if (ctxt->count != 0)
            {
                uint32_t level = 0;
                alt_spi_tx_fifo_level_get(ctxt->device, &level);

                uint32_t space = ALT_SPI_TX_FIFO_NUM_ENTRIES - level;
                space = MIN(space, ctxt->count);

                status = alt_spi_slave_tx_transfer(ctxt->device, ctxt->buffer, space);

                ctxt->count -= space;
                memmove(ctxt->buffer, ctxt->buffer + space, ctxt->count * sizeof(ctxt->buffer[0]));

                printf("INFO [ISR]: TX FIFO Empty. [%" PRIu32 "] item(s) transfered to TXFIFO. [%u] item(s) remaining.\n",
                       space, ctxt->count);
            }

            if (ctxt->count == 0)
            {
                alt_spi_int_disable(ctxt->device, ALT_SPI_STATUS_TXEI);
            }
        }

        if (spi_int & ALT_SPI_STATUS_TXOI) // TX FIFO Overflow
        {
            // Internal error, as we are copying more data is safe.
            printf("ERROR [ISR]: Software Error: TXOI [line:%d].\n", __LINE__);
            status = ALT_E_ERROR;
        }

        if (spi_int & ALT_SPI_STATUS_RXUI) // RX FIFO Underflow
        {
            // Internal error
            printf("ERROR [ISR]: Software Error: RXUI [line:%d].\n", __LINE__);
            status = ALT_E_ERROR;
        }

        if (spi_int & ALT_SPI_STATUS_RXOI) // RX FIFO Overflow
        {
            // Internal error
            printf("ERROR [ISR]: Software Error: RXOI [line:%d].\n", __LINE__);
            status = ALT_E_ERROR;
        }

        if (spi_int & ALT_SPI_STATUS_RXFI) // RX FIFO Full (fuller than threshold)
        {
            uint32_t level = 0;
            status = alt_spi_rx_fifo_level_get(ctxt->device, &level);

            // Sometimes a read request from the master can look like an item coming into the FIFO.
            if (level != 0)
            {
                if (status == ALT_E_SUCCESS)
                {
                    level = MIN(level, ARRAY_COUNT(ctxt->buffer) - ctxt->count);
                    status = alt_spi_slave_rx_transfer(ctxt->device, ctxt->buffer + ctxt->count,
                                                       level);
                }

                if (status == ALT_E_SUCCESS)
                {
                    printf("INFO [ISR]: RX FIFO Full. Read [%" PRIu32 "] item(s) from RX FIFO. Reenabling TXEI interrupt.\n", level);
                    ctxt->count = level;

                    // Now that we have some data in the RAM buffer, enable TXEI interrupts.
                    status = alt_spi_int_enable(ctxt->device, ALT_SPI_STATUS_TXEI);
                }
            }
        }

        // Clear the interrupt in SPI controller.
        ALT_STATUS_CODE int_status = alt_spi_int_clear(ctxt->device, ALT_SPI_STATUS_ALL);
        if (int_status != ALT_E_SUCCESS)
        {
            status = int_status;
        }
    }

    if (status != ALT_E_SUCCESS)
    {
        printf("ERROR [ISR]: Bad status encountered. Disabling interrupt.\n");

        // Report ISR failure to context.
        ctxt->status = status;

        // Disable interrupt at GIC.
        alt_int_dist_disable((ALT_INT_INTERRUPT_t)ALT_INT_ICCIAR_ACKINTID_GET(icciar));
    }
}

/******************************************************************************/
/*!
 * SPI Demo Master Slave Loopback Test.
 *
 * \param       SPI master device, SPI slave device
 * \return      result of the function
 */
ALT_STATUS_CODE spi_demo_master_slave_loopback(ALT_SPI_DEV_t * device_master, ALT_SPI_DEV_t * device_slave, SPI_SLAVE_CONTEXT_t * slave_context)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    for (int size = 1; size <= SPI_BUFFER_SIZE; size <<= 1)
    {
       if (status != ALT_E_SUCCESS)
        {
            break;
        }

        if (status == ALT_E_SUCCESS)
        {
            printf("TEST: Buffer size = %d.\n", size);
        }

        if (status == ALT_E_SUCCESS)
        {
            for (int i = 0; i < size; ++i)
            {
                buffer_send[i] = (char)rand();
            }

            printf("INFO: Master transmitting ...\n");

            status = alt_spi_master_tx_transfer(device_master, SPI_SLAVE_SELECT, size, buffer_send);
            
            printf("INFO: Master transmit complete.\n");
            
            if (status != ALT_E_SUCCESS)
            {
                printf("ERROR: alt_spi_master_tx_transfer() failed; status = %d.\n", (int)status);
            }
        }

        if (status == ALT_E_SUCCESS)
        {
            // Disable RXFI interrupt to prevent slave ISR triggers during master receive
            alt_spi_int_disable(device_slave, ALT_SPI_STATUS_RXFI);

            // Zero out the receive buffer
            memset(buffer_recv, 0, sizeof(buffer_recv));

            printf("INFO: Master receiving ...\n");

            status = alt_spi_master_rx_transfer(device_master, SPI_SLAVE_SELECT, size, buffer_recv);
   
            printf("INFO: Master receive complete.\n");

            if (status != ALT_E_SUCCESS)
            {
                printf("ERROR: alt_spi_master_rx_transfer() failed; status = %d.\n", (int)status);
            }

            // Reenable RXFI interrupt
            alt_spi_int_enable(device_slave, ALT_SPI_STATUS_RXFI);

        }

        if (status == ALT_E_SUCCESS)
        {
            printf("INFO: Comparing send and receive buffer ...\n");

            // Compare the send and recv buffer
            if (memcmp(buffer_send, buffer_recv, size * sizeof(uint16_t)) == 0)
            {
                printf("INFO: Buffers match.\n");
            }
            else
            {
                printf("ERROR: Send and Receive buffers does not match.\n");
                status = ALT_E_ERROR;
            }
        }
        
        if (status == ALT_E_SUCCESS)
        {
            if (slave_context->status != ALT_E_SUCCESS)
            {
                status = slave_context->status;
                printf("ERROR: ISR Reported error.\n");
            }
        }
        
        printf("\n");
    }

    return status;
}

/******************************************************************************/
/*!
 * Initialize and setup SPI master and slave device, setup SPI slave interrupt
 *
 * \param       SPI master device, SPI slave device, SPI slave interrupt context
 * \return      result of the function
 */
ALT_STATUS_CODE spi_demo_setup(ALT_SPI_DEV_t * device_master, ALT_SPI_DEV_t * device_slave, SPI_SLAVE_CONTEXT_t * slave_context)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    printf("INFO: Setting up SPI master and slave ...\n");

    // Setup SPI master 
    if (status == ALT_E_SUCCESS)
    {
        status = socfpga_spi_setup_master(device_master);
    }
    // Setup SPI slave 
    if (status == ALT_E_SUCCESS)
    {
        status = socfpga_spi_setup_slave(device_slave);
    }

    // Setup interrupt for SPI slave
    if (status == ALT_E_SUCCESS)
    {
        status = socfpga_int_setup(SPI_SLAVE_IRQ, ALT_INT_TRIGGER_AUTODETECT);
    }

    // Setup interrupt handler for SPI slave
    if (status == ALT_E_SUCCESS)
    {
        status = alt_int_isr_register(SPI_SLAVE_IRQ, spi_slave_isr_callback, slave_context);
    }

    // Setup interrupts for SPI slave
    // Note : TXEI is not enable here to prevent TXEI interrupt before master transmit
    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_int_enable(device_slave, 
                                    ALT_SPI_STATUS_TXOI |
                                    ALT_SPI_STATUS_RXUI |
                                    ALT_SPI_STATUS_RXOI |
                                    ALT_SPI_STATUS_RXFI
                                    );
    }
    
    return status;
}

/******************************************************************************/
/*!
 * Cleanup SPI master and slave device, disable SPI slave interrupt
 *
 * \param       SPI master device, SPI slave device, SPI slave interrupt context
 * \return      result of the function
 */
ALT_STATUS_CODE spi_demo_cleanup(ALT_SPI_DEV_t * device_master, ALT_SPI_DEV_t * device_slave)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    printf("INFO: Cleaning up SPI master and slave ...\n");
    
    // Cleanup SPI master 
    if (status == ALT_E_SUCCESS)
    {
        status = socfpga_spi_cleanup(device_master);
    }
    
    // Cleanup SPI slave 
    if (status == ALT_E_SUCCESS)
    {
        status = socfpga_spi_cleanup(device_slave);  
    }    
    
    // Disable SPI slave interrupt 
    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_int_disable(device_slave, ALT_SPI_STATUS_ALL);
    }
    
    // Cleanup Interrupt
    if(status == ALT_E_SUCCESS)
    {
        status = socfpga_int_cleanup(SPI_SLAVE_IRQ);
    }
    
    return status;
}

/******************************************************************************/
/*!
 * Program entrypoint
 *
 * \return result of the program
 */
int main(void)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    ALT_SPI_DEV_t device_master;
    ALT_SPI_DEV_t device_slave;
    
    SPI_SLAVE_CONTEXT_t slave_context =
    {
        .device = &device_slave,
        .status = ALT_E_SUCCESS,
        .count  = 0
    };
    
    // Configure FPGA
    if (status == ALT_E_SUCCESS)
    {
        status = socfpga_fpga_setup();
    }
    
    // Initialize and set SPI master & slave
    if (status == ALT_E_SUCCESS)
    {
        status = spi_demo_setup(&device_master, &device_slave, &slave_context);
    }

    // Run loopback test
    if (status == ALT_E_SUCCESS)
    {
        status = spi_demo_master_slave_loopback(&device_master, &device_slave, &slave_context);
    }

    // Cleanup loopback test
    if (status == ALT_E_SUCCESS)
    {
        status = spi_demo_cleanup(&device_master, &device_slave);
    }
    
    if (status == ALT_E_SUCCESS)
    {
        status = socfpga_fpga_cleanup();
    }

    // Report status
    if (status == ALT_E_SUCCESS)
    {
        printf("RESULT: All tests successful.\n");
        return 0;
    }
    else
    {
        printf("RESULT: Some failures detected.\n");
        return 1;
    }
}
