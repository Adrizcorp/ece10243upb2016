# Description #
This software is intended to read and write complete disk images from/to SD drives or other USB attached media. The whole media will be written/read via low-level block transfer, so you can make backups or complete rewrite your SD cards.
Very useful for developers who want to setup some SD card for using in embedded systems, f.e. Raspberry Pi.

# Warranty #
The software comes along with absolutly NO warranty. The author is not responsible for any errors or loss of data you experience while using this software. Use this software on your OWN risk.